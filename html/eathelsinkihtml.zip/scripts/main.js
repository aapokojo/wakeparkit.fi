fetch('/data.json')
.then(function(response) {
  return response.json();
})
.then(function(data) {

for (i = 0; i < data.places.length; i++) {
  document.getElementById("kartta").innerHTML
    += '<p '
    + 'style="top:' + data.places[i].top
    + '; left:'+ data.places[i].left
    + ';" class="' + data.places[i].class
    + '">'
    + '<img src="/media/pin.svg" width="22" height="22" /><br>'
    + data.places[i].name
    + '</p>';
  }
});

function select(categoryName, selectionName) {

  elements = document.getElementsByClassName(categoryName)
  for (i = 0; i < elements.length; i++) {
    elements[i].style.opacity = 0.25;
  }
  elements = document.getElementsByClassName(selectionName)
  for (i = 0; i < elements.length; i++) {
    elements[i].style.opacity = 0.9;
  }
  ga('send', 'event', 'button', 'click', selectionName);

}
