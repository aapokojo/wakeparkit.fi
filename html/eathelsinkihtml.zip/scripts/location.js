var options = {
  enableHighAccuracy: true,
  timeout: 5000,
  maximumAge: 0
};

function success(pos) {
  var crd = pos.coords;
  var top = -(crd.latitude - 60.194) * 22727;
  var left = (crd.longitude - 24.90) * 11235;

  document.getElementById("kartta").innerHTML
    += '<p '
    + 'style="top:' + top
    + '; left:'+ left
    + ';" >'
    + '<img src="/media/youpin.svg" width="150" height="150"/><br>'
    + '</p>';
};

function error(err) {
  console.warn(`ERROR(${err.code}): ${err.message}`);
};

navigator.geolocation.getCurrentPosition(success, error, options);
