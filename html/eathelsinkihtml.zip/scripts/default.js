if ( new Date().getHours() < 11) {
  select('food','breku')
} else {
  select('food','casual')
}
